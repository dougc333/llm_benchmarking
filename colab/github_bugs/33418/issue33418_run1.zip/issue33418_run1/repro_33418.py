#!/usr/bin/env python3
"""Probe vLLM issue #33418 against a running server; Python standard library only.

The server must have --max-model-len 2048. This tests request validation,
not GPU exhaustion. No server settings or packages are changed by this client.
"""
import argparse
import datetime as dt
import json
import os
from pathlib import Path
import re
import shutil
import sys
import time
import urllib.error
import urllib.request


def utc():
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="milliseconds")


def classify(status, message, case):
    if case == "valid_control":
        return "control_ok" if status == 200 else "unexpected_control_failure"
    if status != 400:
        return "unexpected_status"
    if case == "combined_length_overflow":
        if re.search(r"maximum context length is\s+3 tokens", message, re.I):
            return "historical_33418_wording_reproduced"
        return "http_400_other_wording_review_response"
    return "expected_http_400"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", default="http://127.0.0.1:8008")
    parser.add_argument("--model", default="Qwen/Qwen2.5-7B-Instruct")
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--timeout", type=float, default=120)
    args = parser.parse_args()
    out = args.output_dir.resolve()
    if (out.exists() and any(out.iterdir())) or Path(str(out) + ".zip").exists():
        parser.error("Use a new output directory; existing results will not be overwritten.")
    out.mkdir(parents=True, exist_ok=True)
    report = {"issue": "https://github.com/vllm-project/vllm/issues/33418",
              "started_utc": utc(), "base_url": args.base_url,
              "model": args.model, "expected_max_model_len": 2048,
              "http_exchanges": [], "cases": []}
    log = (out / "client.log").open("w", buffering=1)

    def emit(message):
        line = f"[{utc()}] {message}"
        print(line, flush=True)
        log.write(line + "\n")

    def request(path, payload=None):
        headers = {"Content-Type": "application/json"}
        # Optional authentication is never recorded in the output.
        if os.environ.get("VLLM_API_KEY"):
            headers["Authorization"] = "Bearer " + os.environ["VLLM_API_KEY"]
        req = urllib.request.Request(args.base_url.rstrip("/") + path,
                                     data=None if payload is None else json.dumps(payload).encode(),
                                     headers=headers)
        record = {"started_utc": utc(), "path": path, "request": payload}
        started = time.monotonic()
        try:
            try:
                response = urllib.request.urlopen(req, timeout=args.timeout)
            except urllib.error.HTTPError as error:
                response = error  # HTTP 400 is the expected test outcome.
            with response:
                record["status"] = response.code
                record["response_text"] = response.read().decode("utf-8", errors="replace")
            try:
                record["response_json"] = json.loads(record["response_text"])
            except json.JSONDecodeError:
                record["response_json"] = None
        except Exception as error:
            record.update(status=None, transport_error=f"{type(error).__name__}: {error}")
        record.update(finished_utc=utc(), elapsed_s=time.monotonic() - started)
        report["http_exchanges"].append(record)
        with (out / "http_exchanges.jsonl").open("a") as stream:
            stream.write(json.dumps(record) + "\n")
        emit(f"{path} HTTP {record['status']}: " + record.get("response_text", record.get("transport_error", "")))
        return record

    exit_code = 0
    try:
        emit("Testing context validation with configured limit 2048; expected prompt length 8.")
        request("/version")
        models = request("/v1/models")
        if models["status"] != 200:
            raise RuntimeError("Cannot read server models; check server readiness and authentication.")
        data = (models.get("response_json") or {}).get("data", [])
        model = next((item for item in data if item.get("id") == args.model), None)
        if model is None:
            raise RuntimeError("Requested model is not listed by this server.")
        actual_limit = model.get("max_model_len")
        if actual_limit is not None and int(actual_limit) != 2048:
            raise RuntimeError(f"Server advertises max_model_len={actual_limit}; restart test server with 2048.")
        if actual_limit is None:
            emit("Server omits max_model_len metadata: results require independently confirming --max-model-len 2048.")
        tokenized = request("/tokenize", {"model": args.model,
                              "prompt": "What is the capital of France?", "add_special_tokens": False})
        tokens = (tokenized.get("response_json") or {}).get("tokens")
        if tokenized["status"] != 200 or not tokens or not all(type(t) is int for t in tokens):
            raise RuntimeError("The server /tokenize endpoint must return integer token IDs.")
        # Integer prompts keep the test at exactly eight tokens across tokenizers.
        prompt = (tokens * 8)[:8]
        for name, maximum in [("valid_control", 1), ("output_limit_overflow", 2049),
                              ("combined_length_overflow", 2045)]:
            emit(f"CASE {name}: prompt_tokens=8, max_tokens={maximum}, sum={8 + maximum}, context=2048")
            result = request("/v1/completions", {"model": args.model, "prompt": prompt,
                             "max_tokens": maximum, "temperature": 0, "stream": False})
            body = result.get("response_json") or {}
            error = body.get("error") or {}
            message = error.get("message", "") if isinstance(error, dict) else str(error)
            verdict = classify(result["status"], message, name)
            report["cases"].append({"name": name, "prompt_tokens": 8,
                                    "max_tokens": maximum, "verdict": verdict, "exchange": result})
            emit(f"VERDICT {verdict}")
            if name == "valid_control":
                count = (body.get("usage") or {}).get("prompt_tokens")
                if result["status"] != 200 or count != 8:
                    raise RuntimeError(f"Control did not confirm eight prompt tokens (reported {count}); stopping.")
            elif result["status"] != 400:
                exit_code = 1
        emit("Other HTTP-400 wording is not proof of a fix: inspect the recorded message and server version.")
    except Exception as error:
        report["fatal_error"] = f"{type(error).__name__}: {error}"
        emit(report["fatal_error"])
        exit_code = 1
    finally:
        report.update(finished_utc=utc(), exit_code=exit_code)
        (out / "results.json").write_text(json.dumps(report, indent=2) + "\n")
        shutil.copyfile(__file__, out / "repro_33418.py")
        emit(f"Saved results in {out}; archive will be {out}.zip")
        log.close()
        shutil.make_archive(str(out), "zip", root_dir=out.parent, base_dir=out.name)
    return exit_code


if __name__ == "__main__":
    sys.exit(main())

